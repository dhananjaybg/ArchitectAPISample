﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EdwardsDemo
{
    class Program
    {
        static void Main(string[] args)
        {



            string userName = "admin";
            string password = "admin";
            try
            {
                // Create proxy instance
                Application25ServiceReference.ApplicationClient applicationClient = new Application25ServiceReference.ApplicationClient();
                applicationClient.ClientCredentials.UserName.UserName = userName;
                applicationClient.ClientCredentials.UserName.Password = password;

                // Execute the GetVersion call
                string version = applicationClient.GetVersion();

                Console.WriteLine(version);

                // Create proxy instance
                User25ServiceReference.UserClient userClient = new User25ServiceReference.UserClient();
                userClient.ClientCredentials.UserName.UserName = userName;
                userClient.ClientCredentials.UserName.Password = password;

                // Create requested metadata xml
                string xmlRequestedMetadata = "&lt;ishfields&gt;" +
                                                  "&lt;ishfield name='USERNAME' level='none'/&gt;" +
                                                  "&lt;ishfield name='FISHUSERDISPLAYNAME' level='none'/&gt;" +
                                                  "&lt;ishfield name='FISHEMAIL' level='none'/&gt;" +
                                                  "&lt;ishfield name='FUSERGROUP' level='none'/&gt;" +
                                                  "&lt;ishfield name='FISHUSERROLES' level='none' ishvaluetype='element'/&gt;" +
                                                  "&lt;ishfield name='FISHEXTERNALID' level='none'/&gt;" +
                                                "&lt;/ishfields&gt;";

                // Execute the GetMyMetadata call
                string xmlObjectList = userClient.GetMyMetadata(xmlRequestedMetadata);

                Console.WriteLine(xmlObjectList);
            }
                /*
            //Catch all Application25 server exceptions that are generated after the request has been validated on the server and executes.
            catch (FaultException<Application25ServiceReference.InfoShareFault> fex)            
            {
                Console.WriteLine("API25 FaultException: {0}", fex);
                Console.WriteLine("Action: {0}", fex.Action);
                Console.WriteLine("Reason: {0}", fex.Reason);
                Console.WriteLine("Description: {0}", fex.Detail.Description);
                Console.WriteLine("InfoShareErrorNumber: {0}", fex.Detail.InfoShareErrorNumber);
                Console.WriteLine("Origin: {0}", fex.Detail.Origin);
                Console.WriteLine("XMLDetail: {0}", fex.Detail.XMLDetail);
            }
            //Catch all User25 server exceptions that are generated after the request has been validated on the server and executes.
            catch (FaultException<User25ServiceReference.InfoShareFault> fex)           
            {
                Console.WriteLine("User25 FaultException: {0}", fex);
                Console.WriteLine("Action: {0}", fex.Action);
                Console.WriteLine("Reason: {0}", fex.Reason);
                Console.WriteLine("Description: {0}", fex.Detail.Description);
                Console.WriteLine("InfoShareErrorNumber: {0}", fex.Detail.InfoShareErrorNumber);
                Console.WriteLine("Origin: {0}", fex.Detail.Origin);
                Console.WriteLine("XMLDetail: {0}", fex.Detail.XMLDetail);
            }
            //Catch all server exception that are generated before the request has been validated on the server and executes.
            //e.g. Token validation
            catch (FaultException fex)
            {
                Console.WriteLine("FaultException: {0}", fex);
                Console.WriteLine("Action: {0}", fex.Action);
                Console.WriteLine("Reason: {0}", fex.Reason);
            }
                */
            //Catch the test
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex);
            }
            finally
            {
                Console.WriteLine("Press any key...");
                Console.ReadLine();
            }

        }
    }
}
